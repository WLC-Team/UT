#pragma once

#include "stdafx.h"
#include "targetver.h"
#include <string.h>

#ifdef IOPATH_EXPORTS
#define IOPATH_API __declspec(dllexport)
#else
#define IOPATH_API __declspec(dllimport)
#endif

//using std::string;
//public enum Directory_enum
//{
//	// Summary:
//    //     The Directory that contains all fax information.  Information is wipeable.
//        FaxDirectory = 0,
//        //
//        // Summary:
//        //     The Directory that contains all
//        CopyDirectory = 1,
//        //
//        // Summary:
//        //     The directory where all customer related datacontracts should be saved to.
//        CustomerDataContractDirectory = 2,
//        //
//        // Summary:
//        //     The directory that contains the customer database,
//        CustomerDatabaseDirectory = 3,
//        //
//        // Summary:
//        //     The directory where all customer related data is stored.
//        CustomerDataDirectory = 4,
//        //
//        // Summary:
//        //     The Directory where customer related IQ tables are stored.
//        CustomerDataIQTablesDirectory = 5,
//        //
//        // Summary:
//        //     Directory that stores all logs that may have customer related information.
//        CustomerLogDirectory = 6,
//        //
//        // Summary:
//        //     The Customer PDL directore.  This is also Volume 0 in the PDL system.
//        CustomerPdlDirectory = 7,
//        //
//        // Summary:
//        //     Backup directory for configuration data.
//        CustomerBackupDirectory = 8,
//        //
//        // Summary:
//        //     Directory for all jobs to be stored.
//        JobsDirectory = 9,
//        //
//        // Summary:
//        //     Directory used by Webkit.
//		BrowserDirectory = 10
//} Directory;
//
//public enum Paths_enum
//{
//// Summary:
//    //     The Directory that contains all fax information.  Information is wipeable.
//        Fax = 0,
//        //
//        // Summary:
//        //     The Directory that contains all
//        Copy = 1,
//        //
//        // Summary:
//        //     The directory where all customer related datacontracts should be saved to.
//        DataContract = 2,
//        //
//        // Summary:
//        //     The directory that contains the customer database,
//        Database = 3,
//        //
//        // Summary:
//        //     The directory where all customer related data is stored.
//        CustomerData = 4,
//        //
//        // Summary:
//        //     The Directory where customer related IQ tables are stored.
//        CustomerDataIQTables = 5,
//        //
//        // Summary:
//        //     Directory that stores all logs that may have customer related information.
//        CustomerLog = 6,
//        //
//        // Summary:
//        //     The Customer PDL directore.  This is also Volume 0 in the PDL system.
//        CustomerPdl = 7,
//        //
//        // Summary:
//        //     Backup directory for configuration data.
//        CustomerBackup = 8,
//        //
//        // Summary:
//        //     Directory for all jobs to be stored.
//        Jobs = 9,
//        //
//        // Summary:
//        //     Directory used by Webkit.
//		Browser = 10
//} Paths;

char Directory_ar[11][30] =
{
	"FaxDirectory",
	"CopyDirectory",
	"CustomerDataContractDirectory",
	"CustomerDatabaseDirectory",
	"CustomerDataDirectory",
	"CustomerDataIQTablesDirectory",
	"CustomerLogDirectory",
	"CustomerPdlDirectory",
	"CustomerBackupDirectory",
	"JobsDirectory",
	"BrowserDirectory"
};

char Paths_ar[11][30] =
{
	"Fax",
	"Copy",
	"CustomerDataContract",
	"CustomerDatabase",
	"CustomerData",
	"CustomerDataIQTables",
	"CustomerLog",
	"CustomerPdl",
	"CustomerBackup",
	"Jobs",
	"Browser"
};


	class IOPATH_API LoadPath
	{
	public:
		//extern "C"
		bool LoadAllPaths();
	};
