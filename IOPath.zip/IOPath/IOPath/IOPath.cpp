// IOPath.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"

#include "IOPathHeader.h"
#include <string>
//#include "iostream.h"
using namespace std;

extern "C" IOPATH_API LoadPath* CreateTestClass(){

	return new LoadPath();
}

extern "C" IOPATH_API void DisposeTestClass(
	LoadPath* pObject)
{
	if (pObject != NULL)
	{
		delete pObject;
		pObject = NULL;
	}
}

extern "C" IOPATH_API bool LoadPath::LoadAllPaths()
{
	char fullPath[11][60];
	std::string mergedPaths = "";
	//std::string slash = "\\";
	for (int i = 0; i <= 10; i++)
	{
		for (int j = 0; j <= 30; j++)
		{
			mergedPaths = Paths_ar[i][j];
		}

		/*if (mergedPaths != "")
			return true;
		else*/
			return true;
	}
}

extern "C" IOPATH_API bool CallLoadAllPaths(
	LoadPath* pObject)
{
	bool result = false;
	if (pObject != NULL)
	{
		result = pObject->LoadAllPaths();
	}

	return result;
}
