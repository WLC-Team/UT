// ManagedBridge.h

#pragma once

using namespace System;

namespace ManagedBridge {

	// Forward declaration
	class UnitTest1;


	public ref class ManagedBridgeClass
	{
	public:
		ManagedBridgeClass();
		//~ManagedBridgeClass();
		//bool LoadPath();
	private:
		

	};
}
