﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace UnitTestProject
{
    class LoadPath : IDisposable
    {
        [DllImport("IOPath.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr CreateTestClass();

        [DllImport("IOPath.dll")]
        static public extern void DisposeTestClass(IntPtr pTestClassObject);

        [DllImport("IOPath.dll")]
        static public extern bool CallLoadAllPaths(IntPtr pTestClassObject);

        private IntPtr m_pNativeObject;

        public LoadPath()
        {
            this.m_pNativeObject = CreateTestClass();
        }

         public void Dispose()
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool bDisposing)
        {
            if (this.m_pNativeObject != IntPtr.Zero)
            {
                // Call the DLL Export to dispose this class
                DisposeTestClass(this.m_pNativeObject);
                this.m_pNativeObject = IntPtr.Zero;
            }

            if (bDisposing)
            {
                // No need to call the finalizer since we've now cleaned
                // up the unmanaged memory
                GC.SuppressFinalize(this);
            }
        }

        ~LoadPath()
        {
          Dispose(false);
        }

        public bool LoadAllPaths()
        {
            bool value = CallLoadAllPaths(this.m_pNativeObject);
            return value;
        }

    }
}
